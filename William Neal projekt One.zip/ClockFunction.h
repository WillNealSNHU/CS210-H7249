#include<iostream>
using namespace std;
//It's a class!!!! It's a class for time ^.^
class ClockFunction {
	//Member da variables
private:
	int hours;
	int minutes;
	int seconds;
	//Member da functions
public:
	ClockFunction();
	ClockFunction(int hrs, int mnts, int secs);
	void setHours(int hrs);
	void setMinutes(int mnts);
	void setSeconds(int secs);
	int getHrs();
	int getMinutes();
	int getSeconds();
	void display24format();
	void display12format();
	void incrementHr();
	void incrementMinute();
	void incrementSec();
};

// Please note the classes and variables will be professional, but my comments will be a little fun.
// My name is here William Neal 