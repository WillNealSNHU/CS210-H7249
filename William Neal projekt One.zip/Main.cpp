/*
Program to display time in 12 and 24 format
*/
#include <cstdlib>
#include<ctime>
#include<Windows.h>
#include "ClockFunction.h"
#pragma warning(disable : 4996)
// kept getting the annoying security error. Clearly this would not be okay but
// in a production value code base but, for the sake of this project I thought it would be acceptable

//Function prototypes
void display(ClockFunction clock);
int menu();

int main()
{
    //Clear da screen
    system("CLS");
    //Current time, what time is it? Hammer time!
    time_t now = time(0);
    //Get seconds, minutes and hour, pretty self explanitory 
    struct tm timeSplitter;
    timeSplitter = *localtime(&now);
    //Create the object
    ClockFunction clock(timeSplitter.tm_hour, timeSplitter.tm_min, timeSplitter.tm_sec);
    //Display formatted time for the user
    display(clock);
    //Sleep just like thread.sleep in Java
    Sleep(1000);
    system("CLS");

    //Display menu to the user yay!
    int opt = menu();
    //While Loop until exit
    while (opt != 4) {
        //Every option
        if (opt == 1) {
            clock.incrementHr();
            display(clock);
        }
        else if (opt == 2) {
            clock.incrementMinute();
            display(clock);
        }
        else if (opt == 3) {
            clock.incrementSec();
            display(clock);
        }
        //Sleep for 1 second
        Sleep(1000);
        system("CLS");
        opt = menu();
    }
    return 0;
}

//Function to display time in seperate formats
void display(ClockFunction clock) {
    cout << "****************************** ******************************\n"
        << " *     12 - Hour Clock       * *        24 - Hour Clock     *\n"
        << " *       ";
    clock.display12format();
    cout << "         * *             ";
    clock.display24format();
    cout << "       *\n"
        << " ***************************** ******************************\n";
}
//User options and return menu
int menu() {
    int opt;
    cout << "\n******************************\n"
        << "* 1 - Add One Hour   *\n"
        << "* 2 - Add One Minute *\n"
        << "* 3 - Add One Second *\n"
        << "* 4 - Exit Program   *\n"
        << "******************************\n";
    cin >> opt;
    return opt;
}